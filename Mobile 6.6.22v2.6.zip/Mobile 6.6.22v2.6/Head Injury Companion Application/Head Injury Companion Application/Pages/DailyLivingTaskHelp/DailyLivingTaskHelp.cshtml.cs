﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace Head_Injury_Companion_Application.Pages
{
    public partial class DailyLivingTaskHelp
    {
        private void making_cup_of_tea_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = true;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = false;
            washing_up.Visible = false;
        }

        private void making_sandwich_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = true;
            washing_up.Visible = false;
        }

        private void washing_up_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = false;
            washing_up.Visible = true;
        }

        private void brushing_teeth_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = true;
            making_sandwich.Visible = false;
            washing_up.Visible = false;
        }
    }
}