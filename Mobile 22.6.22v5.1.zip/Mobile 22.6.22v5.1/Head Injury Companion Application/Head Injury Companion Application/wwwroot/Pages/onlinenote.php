<?php
$con = mysqli_connect("headapp.cub20pif3hru.us-east-1.rds.amazonaws.com","admin","headinjuryapp","usernotes");

// get the post records
$notecont = $_POST['notearea'];

// database insert SQL code
$sql = "INSERT INTO usernotes_tbl (NoteContent) VALUES ('$notecont')";

// insert in database 
if (mysqli_query($con, $sql)){
	echo "Note uploaded" ;
} else {
	echo "Unable to save your note online, please try again later" ;
}

//Close connection
mysqli_close($con);
?>