﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Head_Injury_Companion_Application.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
    }




    namespace Head_Injury_Companion_Application
    {
        public partial class Home : Form
        {
            public Home()
            {
                InitializeComponent();
            }

            static public Font ChangeFontSize(Font font, float fontSize)
            {
                if (font != null)
                {
                    float currentSize = font.Size;
                    if (currentSize != fontSize)
                    {
                        font = new Font(font.Name, fontSize,
                            font.Style, font.Unit,
                            font.GdiCharSet, font.GdiVerticalFont);
                    }
                }
                return font;
            }

            private void tipsandadvice_btn_Click(object sender, EventArgs e)
            {
                TipsAndAdvice tipsandadvice = new TipsAndAdvice();
                tipsandadvice.Show(); //Opens the "TipsAndAdvice" form
            }

            private void helpandsupport_btn_Click(object sender, EventArgs e)
            {
                ApplicationHelpAndSupport ApplicationHelpAndSupport = new ApplicationHelpAndSupport();
                ApplicationHelpAndSupport.Show(); //Opens the "Application Help and Support" form
            }

            private void dailylivingtasks_btn_Click(object sender, EventArgs e)
            {
                DailyLivingTaskHelp DailyLivingTaskHelp = new DailyLivingTaskHelp();
                DailyLivingTaskHelp.Show(); //Opens the "Application Help and Support" form
            }

            private void myreminders_btn_Click(object sender, EventArgs e)
            {
                MyReminders MyReminders = new MyReminders();
                MyReminders.Show(); //Opens the "Application Help and Support" form
            }

            private void mynotes_btn_Click(object sender, EventArgs e)
            {
                MyNotes MyNotes = new MyNotes();
                MyNotes.Show(); //Opens the "My Notes" form
            }

            private void font_size_up_Click(object sender, EventArgs e)
            {
                Title.Font = ChangeFontSize(Title.Font, Title.Font.Size + 1);
                tipsandadvice_btn.Font = ChangeFontSize(tipsandadvice_btn.Font, tipsandadvice_btn.Font.Size + 1);
                dailylivingtasks_btn.Font = ChangeFontSize(dailylivingtasks_btn.Font, dailylivingtasks_btn.Font.Size + 1);
                myreminders_btn.Font = ChangeFontSize(myreminders_btn.Font, myreminders_btn.Font.Size + 1);
                mynotes_btn.Font = ChangeFontSize(mynotes_btn.Font, mynotes_btn.Font.Size + 1);
                helpandsupport_btn.Font = ChangeFontSize(helpandsupport_btn.Font, helpandsupport_btn.Font.Size + 1);
            }

            private void font_size_down_Click(object sender, EventArgs e)
            {
                Title.Font = ChangeFontSize(Title.Font, Title.Font.Size - 1);
                tipsandadvice_btn.Font = ChangeFontSize(tipsandadvice_btn.Font, tipsandadvice_btn.Font.Size - 1);
                dailylivingtasks_btn.Font = ChangeFontSize(dailylivingtasks_btn.Font, dailylivingtasks_btn.Font.Size - 1);
                myreminders_btn.Font = ChangeFontSize(myreminders_btn.Font, myreminders_btn.Font.Size - 1);
                mynotes_btn.Font = ChangeFontSize(mynotes_btn.Font, mynotes_btn.Font.Size - 1);
                helpandsupport_btn.Font = ChangeFontSize(helpandsupport_btn.Font, helpandsupport_btn.Font.Size - 1);
            }

            private void white_background_btn_Click(object sender, EventArgs e)
            {
                this.BackColor = Color.White;
            }

            private void yellow_background_btn_Click(object sender, EventArgs e)
            {
                this.BackColor = Color.Yellow;
            }

            private void blue_background_btn_Click(object sender, EventArgs e)
            {
                this.BackColor = Color.Blue;
            }

            private void black_background_btn_Click(object sender, EventArgs e)
            {
                this.BackColor = Color.Black;
            }

            private void white_text_btn_Click(object sender, EventArgs e)
            {
                Title.ForeColor = Color.White;
                background_colour_lbl.ForeColor = Color.White;
                text_colour_lbl.ForeColor = Color.White;
                font_size_lbl.ForeColor = Color.White;
            }

            private void yellow_text_btn_Click(object sender, EventArgs e)
            {
                Title.ForeColor = Color.Yellow;
                background_colour_lbl.ForeColor = Color.Yellow;
                text_colour_lbl.ForeColor = Color.Yellow;
                font_size_lbl.ForeColor = Color.Yellow;
            }

            private void red_text_btn_Click(object sender, EventArgs e)
            {
                Title.ForeColor = Color.Red;
                background_colour_lbl.ForeColor = Color.Red;
                text_colour_lbl.ForeColor = Color.Red;
                font_size_lbl.ForeColor = Color.Red;
            }

            private void black_text_btn_Click(object sender, EventArgs e)
            {
                Title.ForeColor = Color.Black;
                background_colour_lbl.ForeColor = Color.Black;
                text_colour_lbl.ForeColor = Color.Black;
                font_size_lbl.ForeColor = Color.Black;
            }
        }
    }
}