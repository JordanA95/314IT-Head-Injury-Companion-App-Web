﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Head_Injury_Companion_Application.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
    }
}


namespace Head_Injury_Companion_Application
{
    public partial class ApplicationHelpAndSupport : Form
    {
        public ApplicationHelpAndSupport()
        {
            InitializeComponent();
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            string send_new_query = "mailto:adamson10[at]uni.coventry.ac.uk?subject=New Head Injury Companion App query&amp;body=new_question_txb.Text";
            System.Diagnostics.Process.Start(send_new_query); //executes the send_new_query process which creates an email populated with recipient email, subject, and the question entered into the new_question_txb textbox.
        }
    }
}