﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace Head_Injury_Companion_Application.Pages
{
    public partial class MyNotes
    {
        /*private void new_btn_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("If a note is open, any unsaved changes to your existing note will be lost. Are you sure you want to create a new note?", "New Note", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                notearea.Text = "";
                notearea.Visible = true;
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream s = File.Open(saveFileDialog1.FileName, FileMode.CreateNew))
                using (StreamWriter sw = new StreamWriter(s))
                {
                    sw.Write(notearea.Text);
                }
            }
        }

        private void open_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialogue1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string s = File.ReadAllText(openFileDialog1.FileName);
                notearea.Text = s;
            }
        }*/
    }
}