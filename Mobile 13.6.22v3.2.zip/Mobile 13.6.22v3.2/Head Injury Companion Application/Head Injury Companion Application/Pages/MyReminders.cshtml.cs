﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace Head_Injury_Companion_Application.Pages
{
    public partial class MyReminders
    {
        private System.Timers.Timer timer;
        public MyReminders()
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += Timer_Elapsed;
        }

        private void startButton_Click()
        {
            timer.Start();
            MessageBox.Show("Your reminder has been set", "Reminder");
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            DateTime userTime = dateTimePicker1.Value;
            if (currentTime.Hour == userTime.Hour && currentTime.Minute == userTime.Minute && currentTime.Second == userTime.Second)
            {
                timer.Stop();
                try
                {
                    MessageBox.Show(remindermessage.Text);
                }
                catch
                {
                    MessageBox.Show(remindermessage.Text, "Reminder!");
                }
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer.Stop();
            MessageBox.Show("Your reminder has been canceled!", "Reminder");
        }
    }
}